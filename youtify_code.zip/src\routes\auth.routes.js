const express=require('express')
const {register,login,me}=require('../controller/auth.controller')
const{authMiddleware}=require('../middleware/auth.middleware')

const router=express.Router()

router.post('/register',register)
router.post('/login',login)
router.get('/me', authMiddleware, me)
module.exports=router